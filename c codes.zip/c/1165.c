#include<stdio.h>
#include<math.h>
int isprime(int n)
{
    if( n==1) return 1;
    else if(n==2) return 1;
    else if(n%2==0) return 0;
    else
    {
        int i;
        for(i=3;i<=(int)sqrt(n);i+=2)
            if(n%i==0) return 0;
    }
    return 1;
}

void main()
{
    int n,i,x;
    scanf("%d",&n);
    for(i=1;i<=n;i++)
    {
        scanf("%d",&x);
        if(isprime(x)==1)
            printf("%d eh primo\n",x);
        else
            printf("%d nao eh primo\n",x);
    }

}
