#include<stdio.h>

unsigned long long p(int n,int r)
{
    int i=n;
    unsigned long long q=1;
    while(r--)
    {
        q=q*i;
        i--;
    }
    return q;
}

int main()
{
    printf("%llu",p(100,3));
    return 0;
}
