#include<stdio.h>
#include<math.h>

void main()
{
    int x1,x2,y1,y2,z1,z2;
    printf("Enter the components of 1st vector:");
    scanf("%d %d %d",&x1,&y1,&z1);
    printf("Enter the components of 2nd vector:");
    scanf("%d %d %d",&x2,&y2,&z2);
    printf("Angle between two vector is: %lf radians\n",acos((x1*x2+y1*y2+z1*z2)/(sqrt(x1*x1+y1*y1+z1*z1)*sqrt(x2*x2+y2*y2+z2*z2))));
    printf("Angle between two vector is: %lf degrees\n",(acos((x1*x2+y1*y2+z1*z2)/(sqrt(x1*x1+y1*y1+z1*z1)*sqrt(x2*x2+y2*y2+z2*z2)))*180.0)/3.1416);
}

