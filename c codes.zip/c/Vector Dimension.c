#include<stdio.h>

void main()
{
    int i,j,k;
    printf("Enter components of i,j,k:");
    scanf("%d %d %d",&i,&j,&k);
    if(i*j*k!=0)
        printf("3D");
    else if(i+j+k!=0 && i*j*k==0)
        printf("@D or 1D");
    else
    printf("No Dimension");
}
