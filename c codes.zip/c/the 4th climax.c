#include<stdio.h>

int main()
{
    int x1,x2,x3,y1,y2,y3;
    printf("Enter 3 climaxes serially:");
    scanf("%d %d %d %d %d %d",&x1,&y1,&x2,&y2,&x3,&y3);
    printf("The 4th climax is (%d,%d)",x2+x3-x1,y2+y3-y1);
    return 0;
}
