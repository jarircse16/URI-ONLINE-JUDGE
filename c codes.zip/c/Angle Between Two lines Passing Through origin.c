#include<stdio.h>
#include<math.h>
void main()
{
    int m1,m2,b=1,a;
    float h,theta;
    printf("Enter tangents of two lines:");
    scanf("%d %d",&m1,&m2);
    if(m1==m2)
    {
        printf("Angle is Zero ,Lines are parallel");
    }
    else if(m1+m2==0)
    {
        printf("Angle is 90,Lines are perpendicular");
    }
    else
    {
        theta=atan(m1-m2)/(1+m1*m2);
        printf("Angle between two lines is %f",theta);
    }
}
