#include<stdio.h>

void main()
{
    int N,i;
    scanf("%d",&N);
    if(N>5 && N<2000){
    if(N%2==0){
        for(i=2;i<=N;i+=2)
    {
        printf("%d^%d = %d\n",i,i,i*i);
    }
    }
    if(N%2!=0)
    {
        for(i=2;i<=N;i+=2)
        {
            printf("%d^%d = %d\n",i,i,i*i);
        }

    }
}
}
