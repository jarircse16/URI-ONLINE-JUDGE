#include<stdio.h>
#include<math.h>

int power(int x,int p)
{
    int i,f=1;
    for(i=1;i<=p;i++)
    {
        f=f*x;

    }
    return f;
}
int hash(int x)
{
    return power(~x*~x,1);

}

void main()
{
    int i;
    for(i=1;i<1000;i++)
        printf("%x\n",hash(i));
}
