#include<stdio.h>
#include<math.h>

void main()
{
    int x1,x2,y1,y2;
    printf("Enter 1st point:");
    scanf("%d %d",&x1,&y1);
    printf("Enter 2nd point:");
    scanf("%d %d",&x2,&y2);
    printf("Distance: %f",sqrt((x1-x2)*(x1-x2)+(y1-y2)*(y1-y2)));
}
