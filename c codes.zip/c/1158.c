#include<stdio.h>

void reptile(int x,int y)
{
    int k,sum=0,c=0;

        if(x%2==0)
            x++;
        else
            x+=0;
        for(k=x;;k+=2)
        {
            sum+=k;
            c++;
            if(c==y)
                break;
        }

        printf("%d\n",sum);
}

void main()
{
    int n,i,x,y;
    scanf("%d",&n);
    for(i=1;i<=n;i++)
    {
        scanf("%d %d",&x,&y);
        reptile(x,y);

    }
}
