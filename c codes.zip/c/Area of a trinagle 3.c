#include<stdio.h>
#include<math.h>

void main()
{
    int a,b,c;
    float s,area;
    printf("Enter three arms:");
    scanf("%d %d %d",&a,&b,&c);
    if(a+b>c && b+c>a && a+c>b)
    {
        s=(a+b+c)/2.0;
        area=sqrt(s*(s-a)*(s-b)*(s-c));
        printf("Area: %f",area);
    }
    else
    {
        printf("No triangle can be formed");

    }
}

