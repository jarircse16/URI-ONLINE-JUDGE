#include<stdio.h>

void main()
{
    int i,n;
    long long result=1,count=0;
    scanf("%d",&n);
    for(i=2;;)
    {
        result*=i;
        i+=2;
        count++;
        if(count==n)
            break;
    }
    //for(i=2;i<=n*2;i+=2)

    printf("The result is %lld",result);

}
