#include<stdio.h>

void main()
{
   int x;
   scanf("%x",&x);
   printf("%d",x);
}
