#include<stdio.h>

int main()
{
    int x=44,y=40,*z;
    z=&x;
    printf("x= %d\ny=%d\nz=%x\n",x,y,z);
    y=*z;
    *z=10;
    printf("x=%d\ny=%d\nz=%x\n",x,y,z);
    return 0;
}
