#include<stdio.h>

void main()
{
    int b,c,d,e,sum=0;
    while(1)
    {
        scanf("%d %d",&b,&c);
        if(b<=0 || c<=0)
            break;
        if(b>c)
        {
            d=c;
            e=b;
        }
        else
        {
            d=b;
            e=c;
        }
        sum=0;
        for(;d<=e;d++)
        {
            printf("%d ",d);
            sum+=d;
        }
        printf("Sum=%d\n",sum);

    }
}
