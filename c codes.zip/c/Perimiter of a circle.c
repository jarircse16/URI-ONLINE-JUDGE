#include<stdio.h>

void main()
{

    int r;
    x:printf("Enter radius:");
    scanf("%d",&r);
    if(r>0)
    {
        printf("Perimeter: %f\n",2*3.1416*r);
    }
    else
    {
        printf("Invalid radius value\n");
        goto x;
    }
}
