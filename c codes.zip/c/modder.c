#include<stdio.h>


main()
{
    int x=11111;
    printf("%d",x%10000);
}
