#include<stdio.h>

int main()
{
    int A,N,i,sum=0;
    scanf("%d %d",&A,&N);
    while(1)
    {
        if(N<=0)
            scanf("%d",&N);
        else
        {

        for(i=A;i<A+N;i++)
        {
        sum+=i;
        }
        printf("%d\n",sum);
        break;
        }

    }
    return 0;

}
