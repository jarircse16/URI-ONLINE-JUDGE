#include<stdio.h>
void print(int x)
{
    if(x>9)
        printf("%c",'A'+x-10);
    else
        printf("%d",x);
}
int tobase(int n,int base)
{
    if(n==0)
        printf("0");
    else
    {
        tobase(n/base,base);
        print(n%base);
    }
}
void main ()
{
    tobase(8,2);
}
