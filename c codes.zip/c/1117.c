#include<stdio.h>

void main()
{
    float a,b;

    DY:scanf("%f",&a);
    if(a<0.0  || a>10.0 )
    {
        printf("nota invalida\n");
        goto DY;
    }
    DX:scanf("%f",&b);
    if( b>10.0 || b<0.0)
    {
        printf("nota invalida\n");
        goto DX;
    }
        printf("media = %.2f\n",(a+b)/2.0);
}
