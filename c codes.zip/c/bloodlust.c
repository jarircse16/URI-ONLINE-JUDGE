#include<stdio.h>
int main(){
    int a,b,c;
    scanf("%d",&a);
    for(b=0;b<a;b++){
            cin>>c;
    printf("%.5lf\n",c*1.618033988);
    }
    return 0;
    }
