#include<stdio.h>

void main()
{
    int h,k,r;
    int h1,k1,r1;
    printf("Enter the centers:");
    scanf("%d %d %d %d",&h,&k,&h1,&k1);
    printf("Enter radiuses:");
    scanf("%d %d",&r,&r1);
    int c=h*h+k*k-r*r;
    int c1=h1*h1+k1*k1-r1*r1;
    printf("The circle equation is: x^2+y^2+%dx+%dy+%d=0.\n",-2*h,-2*k,c);
    printf("The circle equation is: x^2+y^2+%dx+%dy+%d=0.\n",-2*h1,-2*k1,c1);
    int a,b,a1,b1;
    printf("Enter middle points of the chord:");
    scanf("%d %d %d %d",&a,&b,&a1,&b1);
    if(a*a+b*b-2*h*a-2*k*b+c>0 || a*a+b*b-2*h*a-2*k*b+c==0 || a1*a1+b1*b1-2*h1*a1-2*k1*b1+c1>0 || a1*a1+b1*b1-2*h1*a1-2*k1*b1+c1==0 )
        printf("This wont form chord\n");
    else
        printf("1st Chord Equation is: x^2+y^2+%dx+%dy+%d=%dx+%dy+%d(x+%d)+%d(y+%d)+%d=0\n",-2*h,-2*k,c,a,b,-2*h,a,-2*k,b,c);
        printf("2nd Chord Equation is: x^2+y^2+%dx+%dy+%d=%dx+%dy+%d(x+%d)+%d(y+%d)+%d=0\n",-2*h1,-2*k1,c1,a1,b1,-2*h1,a1,-2*k1,b1,c1);
        printf("Common Chord Equation is: %dx+%dy+%d=%dx+%dy+%d+%d+%d=0\n",-2*(h-h1),-2*(k-k1),c-c1,a-a1,b-b1,-2*(h-h1)*(a-a1),-2*(k-k1)*(b-b1),c-c1);



}
