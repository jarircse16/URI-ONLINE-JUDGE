#include<stdio.h>

void main()
{
    int h,k,r;
    printf("Enter the center:");
    scanf("%d %d",&h,&k);
    printf("Enter radius:");
    scanf("%d",&r);
    printf("The equation of circle is (x-%d)^2+(y-%d)^2=%d",h,k,r*r);
}
