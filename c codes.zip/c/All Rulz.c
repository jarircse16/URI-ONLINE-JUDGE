#include<stdio.h>

float f(float x)
{
    return(1/(1+x));
}

void s13()
{
    int i,n;
    float a,b,h,y[20],so,se,result,x[20];
    printf("\nEnter values of a,b,h: ");
    scanf("%f%f%f",&a,&b,&h);
    n=(b-a)/h;
    if(n%2==1)
    {
        n=n+1;
    }
    h=(b-a)/n;
    printf("\nValue of n and h are:%d %f\n",n,h);
    printf("\n Y values: \n");
    for(i=0; i<=n; i++)
    {
        x[i]=a+i*h;
        y[i]=f(x[i]);
        printf("\n %f\n",y[i]);
    }
    so=0;
    se=0;
    for(i=1; i<n; i++)
    {
        if(i%2==1)
        {
            so=so+y[i];
        }
        else
        {
            se=se+y[i];
        }

    }
    result=h/3*(y[0]+4*so+2*se+y[n]); // Simpson 1/3 rule
    printf("\nIntegration: is %f",result);
}

void trapizoidal()
{
    int i,n;
    float a,b,h,y[20],so,se,result,x[20];
    printf("\n Enter values of a,b,h:\n");
    scanf("%f%f%f",&a,&b,&h);
    n=(b-a)/h;
    if(n%2==1)
    {
        n=n+1;
    }
    h=(b-a)/n;
    printf("\nrefined value of n and h are:%d  %f\n",n,h);
    printf("\n Y values \n");
    for(i=0; i<=n; i++)
    {
        x[i]=a+i*h;
        y[i]=f(x[i]);
        printf("\n%f\n",y[i]);
    }
    so=0;
    se=0;
    for(i=1; i<n; i++)
    {
        if(i%2==1)
        {
            so=so+y[i];
        }
        else
        {
            se=se+y[i];
        }
    }
    result=h/2*(y[0]+2*so+2*se+y[n]);
    printf("\nThe integrated result is: %f",result);
    getch();
}

void s38()
{
    int i,n;
    float a,b,h,y[20],so,se,result,x[20];
    printf("\n Enter values of a,b,h:\n");
    scanf("%f%f%f",&a,&b,&h);
    n=(b-a)/h;
    if(n%2==1)
    {
        n=n+1;
    }
    h=(b-a)/n;
    printf("\nrefined value of n and h are:%d  %f\n",n,h);
    printf("\n Y values \n");
    for(i=0; i<=n; i++)
    {
        x[i]=a+i*h;
        y[i]=f(x[i]);
        printf("\n%f\n",y[i]);
    }
    so=0;
    se=0;
    for(i=1; i<n; i++)
    {
        if(i%3==0)
        {
            so=so+y[i];
        }
        else
        {
            se=se+y[i];
        }
    }
    result=3*h/8*(y[0]+2*so+3*se+y[n]);
    printf("\nThe integrated result is: %f",result);
    getch();
}

int main()
{
    printf("Integrating the function 1/(1+x)");
    printf("Enter 1 for Simpson 1/3 rule.\nEnter 2 for trapizoidal rule\nEnter 3 for Simpson 3/8 rule.\n");
    int choice;
    printf("Enter your choice:");
    scanf("%d",&choice);
    switch(choice)
    {
	case 1:
		s13();
		break;
	case 2:
		trapizoidal();
		break;
	case 3:
		s38();
		break;
		default: printf("Invalid input");
    }
    return 0;
}
