#include<stdio.h>
#include<math.h>
int main()
{
    int s;
    double f,a;
    printf("Enter roots like a+ib or a-ib to build equation with it's conjugate.");
    printf("\n");
    printf("Enter real and imaginary part serially:");
    scanf("%d %lf",&s,&a);
    printf("The equation is x*x-%dx+%.2lf",2*s,(pow(s,2)+pow(a,2)));

}

