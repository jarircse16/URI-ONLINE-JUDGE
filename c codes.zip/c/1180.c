#include<stdio.h>

void main()
{
    int n,i,min,p;
    scanf("%d",&n);

    int a[n];

    for(i=0;i<n;i++)
    {
        scanf("%d",&a[i]);
    }
    min=a[0];
    p=0;
    for(i=1;i<n;i++)
    {
        if(a[i]<min)
        {
            min=a[i];
            p=i;
        }

    }
    printf("Menor valor: %d\n",a[p]);
    printf("Posicao: %d\n",p);

}
