
#include<stdio.h>
#include<math.h>
//use 20 iterations
long long facti(int n)
{
    int i;
    long long fact=1;
    for(i=1;i<=n;i++)
    {
        fact=fact*i;
    }
    if(n==0 || n==1)
        return 1;
    else
        return n*facti(n-1);
}
void main()
{
    int n;
    scanf("%d",&n);
    long long result=facti(2*n)/(pow(2,n)*facti(n));
    printf("The result is %lld",result);
}
