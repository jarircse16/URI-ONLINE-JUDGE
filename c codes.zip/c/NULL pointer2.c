#include<stdio.h>

void main()
{
    int *ptr=NULL,x=16;
    printf("%04Xh %02Xh\n",ptr,*ptr);
    ptr=&x;
    printf("%04Xh %02Xh\n",ptr,*ptr); //Crashes


}
