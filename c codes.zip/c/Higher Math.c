#include<stdio.h>
#include<math.h>

int max(int a,int b,int c)
{
    int m=a;
    if(b>m)
        m=b;
    if(c>m)
        m=c;
    return m;
}
int min(int a,int b,int c)
{
    int m=a;
    if(b<m)
        m=b;
    if(c<m)
        m=c;
    return m;
}


int main()
{
    int cs,cn=0,a,b,c,ma,mi,s;
    double ss;
    scanf("%d",&cs);
    while(cs--)
    {
        scanf("%d %d %d",&a,&b,&c);
        ma=max(a,b,c);
        mi=min(a,b,c);
        s=sqrt(ma*ma-mi*mi);
        ss=sqrt(ma*ma-mi*mi);
        if(s*1.0==ss)
        {
            printf("Case %d: yes\n",++cn);
        }
        else
        {
            printf("Case %d: no\n",++cn);

        }

    }
        return 0;
}
