#include<stdio.h>


int main()
{
    int n1,n2,t,count=0;
    printf("Enter the 1st array size:");
    scanf("%d",&n1);
    int a[n1],i;
    printf("Enter the 1st array:");
    for(i=0;i<n1;i++)
    {
        scanf("%d",&a[i]);
    }
    printf("Enter the 2nd array size:");
    scanf("%d",&n2);
    int b[n2];
    printf("Enter the 2nd array:");
    for(i=0;i<n2;i++)
    {
        scanf("%d",&b[i]);
    }
    int j;
    for(i=0;i<n1;i++){
        for(j=0;j<n2;j++){
            if(a[i]==b[j]){
                count++;
                printf("\nCommon element:%d\n",a[i]);

}
        }
    }
        if(count!=0)
            printf("\nCommon elements found:%d",count);
        else
            printf("No common elements");
     return 0;
}
