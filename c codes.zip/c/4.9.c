#include<stdio.h>

int main()
{
    int n;
    printf("Enter number of elements:");
    scanf("%d",&n);
    int a[n],i,x;
    printf("Enter elements:");
    for(i=0;i<n;i++)
    {
        scanf("%d",&a[i]);
    }
    printf("Enter searchables:");
    scanf("%d",&x);
    int j=1,l;
    while(j<=n && x!=a[j])
    {
         j++;
        if(j<=n && x==a[j])
        {
            printf("Location: %d",j);
            break;
        }
        else
        {
            printf("Not found");
            break;
        }

    }
}
