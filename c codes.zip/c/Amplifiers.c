#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<time.h>

int random()
{
    return rand()%100;
}

int non_inverting_amplifier(int v2,int v3,int A)
{
    printf("Output voltage: %d\n",A*v3-A*v2);
    float R=random();
    float Rf=A*R;
    printf("Resistance: %f\n",R);
    printf("Feedback Resistance: %f\n",Rf);
}
int inverting_amplifier(int v2,int v3,int A)
{
    printf("Output voltage: %d\n",A*v3-A*v2);
    float R=random();
    if(A>0)
        A*=-1;
    else A*=1;
    float Rf=A*R;
    printf("Resistance: %f\n",R);
    printf("Feedback Resistance: %f\n",Rf);
    return 0;
}

int summing_amplifier(int v1,int v2,int v3)
{
    printf("Output Voltage: %d\n",(-1)*(v1+v2+v3));
    float R=random();
    printf("Rf=R1=R2=R3= %f",R);
    return 0;
}

int substractor()
int integrator()
int differentiator()
int comparator()
int schmitt_trigger()
int wein_bridge()


