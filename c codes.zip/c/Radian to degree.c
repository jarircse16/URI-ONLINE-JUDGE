#include<stdio.h>
#include<math.h>

void main()
{
    double rad;
    printf("Enter Radian value:");
    scanf("%lf",&rad);
    printf("Degree Value is %lf",(rad*180.0)/3.1416);
}
