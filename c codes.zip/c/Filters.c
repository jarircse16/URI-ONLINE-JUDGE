#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<time.h>
#define pi acos(-1)

double random()
{
    int r=rand()%100;
    if(r>0)
        return r;
    else
        return r*(-1.0);
}
int all_pass()
{
    srand(time(NULL));
    float av,R1,Rf,R,f,c;
    printf("Enter voltage gain:");
    scanf("%f",&av);
    printf("Enter Capacitance:");
    scanf("%f",&c);
    printf("Enter frequency:");
    scanf("%f",&f);
    R1=random();
    Rf=(av-1)*R1;
    double an=((-2)*atan(2*pi*f*R1*c))*(180.0/pi);
    printf("R=%lf R1=%lf Rf=%lf\n",R,R1,Rf);
    printf("Phase angle=%lf\n",an);
}

int lowpass_highpass()
{
    srand(time(NULL));
    float av,fc,c,R1,Rf,R;
    printf("Enter cut off frequency:");
    scanf("%f",&fc);
    printf("Enter voltage gain:");
    scanf("%f",&av);
    printf("Enter capacitance:");
    scanf("%f",&c);
    R=1.0/2*pi*fc*c;
    R1=random();
    Rf=(av-1)*R1;
    printf("R=%lf\nR1=%lf\nRf=%lf",R,R1,Rf);

}

int narrow_band_pass()
{
    srand(time(NULL));
    float fc,q,af,c,r1,r2,r3;
    printf("Enter Cut off frequency:");
    scanf("%f",&fc);
    printf("Enter Quality factor:");
    scanf("%f",&q);
    printf("Enter gain:");
    scanf("%f",&af);
    printf("Enter Capacitance C:");
    scanf("%f",&c);
    r1=(q)/(2*pi*fc*c*af);
    r2=(q)/(2*pi*fc*c*2*q*q-2*pi*fc*c*af);
    r3=(q)/(pi*fc*c);
    printf("R1=%lf\nR2=%lf\nR3=%lf\n",r1,r2,r3);
}

int narrow_band_reject()
{
    srand(time(NULL));
    float fn,R,c;
    printf("Enter cut off frequency:");
    scanf("%f",&fn);
    printf("Enter capacitance:");
    scanf("%f",&c);
    R=1/(2*pi*fn*c);
    printf("R=%lf",R);

}
int main()
{
    int choice;
    again:printf("Enter 1 for High pass filter\nEnter 2 for Low pass filter\nEnter 3 for Wide bandpass filter\nEnter 4 for Wide band reject filter\nEnter 5 for All pass filter\nEnter 6 for Narrow Band pass filter\nEnter 7 for Narrow band reject filter\nEnter 8 for Exit\n");
    printf("Enter your choice:");
    scanf("%d",&choice);
    if(choice <0 || choice >8)
        goto again;
    else
    {
    switch(choice)
    {
            case 1:
                {
                    printf("Enter data for high pass filter:\n");
                    lowpass_highpass();
                    return 0;
                }
            case 2:
                {
                    printf("Enter data for low pass filter:\n");
                    lowpass_highpass();
                    return 0;
                }
            case 3:
                {
                    printf("Enter data for high pass filter:\n");
                    lowpass_highpass();
                    printf("\n");
                    printf("Enter data for low pass filter:\n");
                    lowpass_highpass();
                    return 0;
                }
            case 4:
                {

                    printf("Enter data for low pass filter:\n");
                    lowpass_highpass();
                    printf("\n");
                    printf("Enter data for high pass filter:\n");
                    lowpass_highpass();
                    return 0;
                }
            case 5:
                {
                    printf("Enter Data for all pass filter:\n");
                    all_pass();
                    return 0;
                }
            case 6:
                {
                    printf("Enter Data for narrow band pass filter:\n");
                    narrow_band_pass();
                    return 0;
                }
            case 7:
                {
                    printf("Enter Data for narrow band reject filter:\n");
                    narrow_band_reject();
                    return 0;
                }
            case 8:
                {
                    return 0;
                }
            default: goto again;

    }
    }
    return 0;
}
