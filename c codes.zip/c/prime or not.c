#include<stdio.h>
#include<math.h>


int isprime(int n)
{
    int i;
    if(n==2)
        return 1;
    else if(n%2==0)
        return 0;
    else
    {
        for(i=3;i<=(int)sqrt(n);i+=2)
        {
            if(n%i==0)
                return 0;
            else
                return 1;
        }
    }

    return 1;

}

int main()
{
    int L,H,i; ///eerroors//
    scanf("%d %d",&L,&H);
    for(i=L;i<=H;i++){

                if(i%2==1)
                {
                    if(isprime(i)==1)
                        printf("%d \t",i);
                        //printf("%d is Prime\n",i);
                    //else
                      //  printf("%d is Composite\n",i);
                }
                //else
                  //  printf("%d is Composite\n",i);
}
return 0;
}
