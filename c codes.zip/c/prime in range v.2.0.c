#include<stdio.h>
#include<math.h>
int isprime(int n)
{
    if(n==2) return 1;
    else if(n%2==0) return 0;
    else
    {
        int i;
        for(i=3;i<=(int)sqrt(n);i+=2)
            if(n%i==0) return 0;
    }
    return 1;
}
int main()
{
    int n,m,i,j,count=0;
    printf("Enter highest and lowest value:");
    scanf("%d %d",&n,&m);
    if(m>n){
        i=n;
        j=m;
    }
    else{
        i=m;
        j=n;
    }
    for(;i<=j;i++)
    {
        if(isprime(i)==1)
        {
            printf("%5d",i);
            count++;
        }
    }
    printf("\nTotal primes: %d",count);
    return 0;
}
