
#include<stdio.h>
#include<stdlib.h>
#include<math.h>


int max(int x,int y,int z)
{
    return ((( x+y+abs(x-y))/2)+z+abs(((x+y+abs(x-y))/2)-z))/2;
}

int main()
{
    printf("Enter three numbers to check:");
    int a,b,c;
    scanf("%d %d %d",&a,&b,&c);
    printf("The maximum among three is: %d",max(a,b,c));
    return 0;
}
