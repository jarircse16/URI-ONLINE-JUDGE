#include<stdio.h>
#include<math.h>

void main()
{
    int n;
    printf("Enter a number:");
    scanf("%d",&n);
    printf("Nearest integer value: %f",floor(sqrt(n)));
}
