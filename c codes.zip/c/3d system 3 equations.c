#include<stdio.h>

void main() /*Contains errors*/
{
    printf("A program to solve anX+bnY+cnZ+dn=0:\n");
    float a1,a2,b1,b2,c1,c2,a3,b3,c3,d1,d2,d3;
    printf("Enter a1,b1,c1,d1:");
    scanf("%f %f %f %f",&a1,&b1,&c1,&d1);
    printf("Enter a2,b2,c2,d2:");
    scanf("%f %f %f %f",&a2,&b2,&c2,&d2);
    printf("Enter a3,b3,c3,d3:");
    scanf("%f %f %f %f",&a3,&b3,&c3,&d3);
    float p=(b1*c2+b1*d2-b2*c1-b2*d1);
    float q=(d1*a2+d1*b2-d2*a1-d2*b1);
    float r=(c1*d2-c2*d1+a1*d2-a2*d1);
    if(p==0 && q==0 && r==0)
        printf("No solutions");
    else if (p==0 && q!=0 && r!=0)
        printf("Infinitely many solutions solutions");
    else
    {
        float z=(((-1)*d3)/(((a3*p)/q)+((b3*r)/q)+c3));
        float x=(z*p)/q;
        float y=(z*r)/q;
        printf("X=%f Y=%f Z=%f",x,y,z);
    }




}
