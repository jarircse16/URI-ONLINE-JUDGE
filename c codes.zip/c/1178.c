#include <stdio.h>
int main()
{
    int y;
    double x;
    scanf ("%lf", &x);
    for(y=0; y<100; y++)
    {
        printf("N[%d] = %lf\n",y,x);
        x=x/2.0;
   }
    return 0;
}
