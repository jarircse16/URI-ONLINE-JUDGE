#include<stdio.h>

void fuck(int x)
{
    int k,sum=0,i;
    for(i=1;i<x;i++)
    {
        if(x%i==0)
            sum+=i;
    }
    if(sum==x)
        printf("%d eh perfeito\n",x);
    else
        printf("%d nao eh perfeito\n",x);

}

void main()
{
    int n,i,x;
    scanf("%d",&n);
    for(i=1;i<=n;i++)
    {
        scanf("%d",&x);
        fuck(x);
    }
}

