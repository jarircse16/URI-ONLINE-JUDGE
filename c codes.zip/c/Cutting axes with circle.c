#include<stdio.h>
#include<math.h>

void main()
{
    int h,k,r;
    printf("Enter the center:");
    scanf("%d %d",&h,&k);
    printf("Enter radius:");
    scanf("%d",&r);
    int c=h*h+k*k-r*r;
        printf("The circle equation is: x^2+y^2+%dx+%dy+%d=0.\n",-2*h,-2*k,c);
    if(2*sqrt(4*k*k-c)==0)
        printf("It touches x-axis in point (%d,0)",2*h);
    else
        printf("Length of portion cut from x axis is: %f\n",2*sqrt(4*k*k-c));
    if(2*sqrt(4*h*h-c)==0)
        printf("It touches x-axis in point (0,%d)",2*k);
    else
        printf("Length of portion cut from y axis is: %f\n",2*sqrt(4*h*h-c));
}
