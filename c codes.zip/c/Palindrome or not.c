#include<stdio.h>
#include<string.h>

void main()
{
    char x[20],y[20];
    gets(x);
    strcpy(y,x);
    strrev(y);
    if(strcmp(x,y)==0)
        printf("Palindrome");
    else
        printf("Not Palindrome");
}
