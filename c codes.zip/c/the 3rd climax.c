#include<stdio.h>
#include<math.h>

int main()
{
    int x1,x2,y1,y2;

    printf("Enter 2 climaxes serially:");
    scanf("%d %d %d %d",&x1,&y1,&x2,&y2);
     float x3p=(x1+x2+sqrt(3)*(y1-y2))/2.0,y3p=(y1+y2-sqrt(3)*(x1-x2))/2.0,x3s=(x1+x2-sqrt(3)*(y1-y2))/2.0,y3s=(y1+y2+sqrt(3)*(x1-x2))/2.0;
    if((x1*y2+x2*y3p+x3p*y1-x1*y3p-x3p*y2-x2*y1)==0 || (x1*y2+x2*y3s+x3s*y1-x1*y3s-x3s*y2-x2*y1)==0)
        printf("Cant form a triangle");
    else{
    printf("The Primary 3rd climax is (%f,%f)\n",x3p,y3p);
    printf("The Secondary 3rd climax is (%f,%f)\n",x3s,y3s);
    }
    return 0;
}

