#include<stdio.h>
#include<string.h>

int main()
{
    int i,j,k,e=0;
    char x[20],y[20];
    printf("Enter the 1st string:");
    gets(x);
    printf("Enter the 2nd string:");
    gets(y);
    if(strlen(x)>strlen(y))
        for(i=0,j=strlen(x),k=strlen(y);i<strlen(x),j>-1,k>-1;i++,j--,k--)
    {
        if(x[i]==y[i] && x[j]==y[k])
            e=1;
        else
            e=0;
    }
    if(e==1)
        printf("Subsequence");
    else
        printf("Not subsequence");
    return 0;
}
