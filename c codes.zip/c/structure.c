#include<stdio.h>

typedef struct student
{
    char name[30],father[30],address[30];
    int birth_date,birth_month,birth_year,phone;
} student;

int main()
{
    student s,Student[50];
    scanf("%s",s.name);
    scanf("%d",&Student[5].birth_date);
    printf("%d\n",Student[5].birth_date);
    return 0;
}
