#include<stdio.h>

void main()
{
    int i;
    for(i=2;i<102;i+=2)
    {
        printf("%d\n",i);
    }

}
