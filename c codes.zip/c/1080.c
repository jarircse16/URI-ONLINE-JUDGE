#include<stdio.h>

void main()
{
    int a[100],i,pos,max;
    for(i=0;i<100;i++)
    {
        scanf("%d",&a[i]);
    }
    max=a[0];
    pos=0;
    for(i=1;i<100;i++)
    {
        if(max<a[i])
        {
             max=a[i];
            pos=i;
        }
        }
        printf("%d\n%d\n",max,pos+1);
}
