#include<stdio.h>
#include<math.h>

void main()
{
    int ox=0,oy=0,x,y,theta;
    double a,b;
    printf("Enter the point:");
    scanf("%d %d",&x,&y);
    printf("The Default point with respect to (%d,%d) is (%d,%d).\n",ox,oy,x-ox,y-oy);

    printf("Enter the rotation angle:");
    scanf("%d",&theta);
    a=x*cos(theta)-y*sin(theta);
    b=x*sin(theta)+y*cos(theta);
    printf("The New point with respect to %d degree rotation is (%lf,%lf).\n",theta,a,b);
}
