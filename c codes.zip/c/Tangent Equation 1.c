#include<stdio.h>

void main()
{
    int h,k,r;
    printf("Enter the center:");
    scanf("%d %d",&h,&k);
    printf("Enter radius:");
    scanf("%d",&r);
    int c=h*h+k*k-r*r;
    printf("The circle equation is: x^2+y^2+%dx+%dy+%d=0\n",-2*h,-2*k,c);
    int x1,y1;
    printf("Enter Tangent Point:");
    scanf("%d %d",&x1,&y1);
    if(x1*x1+y1*y1-2*h*x1-2*k*y1+c<0)
        printf("Can't form any tangent");
    else if(x1*x1+y1*y1-2*h*x1-2*k*y1+c==0)
        printf("Tangent Equation %dx+%dy+%d(x+%d)+%d(y+%d)+%d=0",x1,y1,-1*h,x1,-1*k,y1,c);
    else
        printf("Tangent Equation %dx+%dy+%d(x+%d)+%d(y+%d)+%d=(x^2+y^2+%dx+%dy+%d)*%d",x1,y1,-1*h,x1,-1*k,y1,c,-2*h,-2*k,c,x1*x1+y1*y1-2*h*x1-2*k*y1+c);

}
