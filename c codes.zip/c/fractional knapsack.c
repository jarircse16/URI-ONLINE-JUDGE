#include<stdio.h>

int xe[5];

int main()
{
////////////////Variable Declarations/////////////
    int w[5],p[5],q[5],c,d,swap,swap2,i,j,t,u,r,s,weight=30,taken=0,x,y,f[5],e,h,a,n=0,price=0;
    float total;
//////////////////////////////////Inputs/////////////////
    printf("Enter weights:");

    for(i=0;i<5;i++)
    {
        scanf("%d",&w[i]);
    }
    printf("Enter profits:");

    for(j=0;j<5;j++)
    {
        scanf("%d",&p[j]);
        q[j]=p[j];
    }
//////////////////////Test printing 1 ///////////////////////////////////////////////////////////////////

printf("Before sorting:\n");
printf("Array of Weights:");
for(r=0;r<5;r++)
    {
        printf("%d ",w[r]);
    }
    printf("\n");
printf("Array of Profits:");
for(s=0;s<5;s++)
{
    printf("%d ",p[s]);
}
printf("\n");

///////////////////Sorting the profits and the weights with respect to profit//////////////////////////////
    for (c = 0 ; c < 5; c++)
    {
        for (d = 0 ; d < 5 - c - 1; d++)
            {
                if (p[d] > p[d+1])
                    {
                        swap   = p[d];
                        swap2=w[d];
                        p[d]   = p[d+1];
                        w[d]=w[d+1];
                        p[d+1] = swap;
                        w[d+1]=swap2;
                    }
            }
    }


//////////////////////Test Printing 2 ////////////////////

printf("After sorting:\n");
printf("Array of Weights:");
for(t=0;t<5;t++)
    {
        printf("%d ",w[t]);
    }
    printf("\n");
printf("Array of Profits:");
for(u=0;u<5;u++)
{
    printf("%d ",p[u]);
}
printf("\n");
///////////////////////Desend sort////////////////////////

for(e=4,h=0;e>=0;e--,h++)
{
    f[h]=w[e];
}
////////////////////////////////////////
printf("After sorting:\n");
printf("Array of Weights(Descend sort):");
for(a=0;a<5;a++)
    {
        printf("%d ",f[a]);
    }
    printf("\n");
////////////////////////////Fractional Knapsack/////////////////////


for(x=0;x<=4;x++)
{
    if(f[x]<weight)
    {
        taken+=f[x];
        price+=p[4-x];
        weight=weight-f[x];
        xe[x]=1;
        n++;
    }
    else
    {
        xe[x]=0;
    }
    total=price+((f[n]*weight)/p[4-n]);
}

///////////////////////////Final output///////////////////////////
printf("Price gained:%.3f\n",total);
printf("Indexes of elements stolen:");
for(y=0;y<5;y++)
{
    if(xe[y]==1)
        printf("%d ",y);
}

return 0;
}

