#include<stdio.h>
#include<string.h>
void main()
{
    int n,i;
    printf("Enter Digit limit:");
    scanf("%d",&n);
    char x[n];
    printf("Enter numbers upto %d digits:",n);
    for(i=0;i<=n;i++)
    {
        scanf("%c",&x[i]);
    }
    if(x[n]=='1' || x[n]=='3' || x[n]=='5' || x[n]=='7' || x[n]=='9')
        printf("Odd");
    else
        printf("Even");
}
