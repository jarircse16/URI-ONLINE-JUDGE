#include<string.h>
#include<stdio.h>


int main()
{
    int i;
    char bin[8];
    gets(bin);
    strrev(bin);
    for(i=1;i<8;i++)
    {
        bin[i]=1-bin[i]+2*'0';
    }

    char x=bin[0]-'0'+1;
    char c=bin[0]/2;
    bin[0]=x%2+'0';
    for(i=1;i<8;i++)
    {
        x=bin[i]-'0'+c;
        c=x/2;
        bin[i]=x%2+'0';
    }
    printf("%s",strrev(bin));
    }

