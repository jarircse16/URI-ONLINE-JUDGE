#include<stdio.h>

int main()
{
    int n;
    printf("Enter number of elements:");
    scanf("%d",&n);
    int a[n],i,x;
    printf("Enter elements:");
    for(i=0;i<n;i++)
    {
        scanf("%d",&a[i]);
    }
    printf("Enter searchables:");
    scanf("%d",&x);
    int j=1,k=n,m,l;
    while(j<k)
    {
        m=(j+k)/2;
        if(x>a[m])
            j=m+1;
        else
            k=m;
        if(x==a[j])
        l=j;
        else
        l=0;

    }
    printf("Location:%d",l);
}
