#include<stdio.h>
#include<string.h>

int main()
{
    int i,e=0;
    char x[20],y[20];
    printf("Enter the 1st string:");
    gets(x);
    printf("Enter the 2nd string:");
    gets(y);
    if(strlen(x)>strlen(y)){
        printf("1st string is bigger\n");
        return 0;
    }
    else if(strlen(x)<strlen(y))
    {
        printf("2nd string is bigger\n");
        return 0;
    }

    else
    {
        for(i=0;i<strlen(x);i++)
        {
            if(x[i]>y[i]){
                e=1;
                break;
            }
            else if(x[i]<y[i]){
                e=-1;
                break;
        }
        }
    }
    if(e==1){
        printf("1st string is bigger.\n");
        return 0;
    }
    else if(e==-1){
        printf("2nd string is bigger");
        return 0;
    }
    else {
        printf("Equal");
        return 0;
    }
}
