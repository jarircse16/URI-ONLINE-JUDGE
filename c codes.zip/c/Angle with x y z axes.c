#include<stdio.h>
#include<math.h>

void main()
{
    int x1,y1,z1;
    printf("Enter the components of 1st vector:");
    scanf("%d %d %d",&x1,&y1,&z1);
    printf("Angle with x-axis is: %lf radians\n",acos(x1/(sqrt(x1*x1+y1*y1+z1*z1))));
    printf("Angle with x-axis  is: %lf degrees\n",((acos(x1/(sqrt(x1*x1+y1*y1+z1*z1))))*180.0)/3.1416);
    printf("Angle with y-axis is: %lf radians\n",acos(y1/(sqrt(x1*x1+y1*y1+z1*z1))));
    printf("Angle with y-axis  is: %lf degrees\n",((acos(y1/(sqrt(x1*x1+y1*y1+z1*z1))))*180.0)/3.1416);
    printf("Angle with z-axis is: %lf radians\n",acos(z1/(sqrt(x1*x1+y1*y1+z1*z1))));
    printf("Angle with z-axis  is: %lf degrees\n",((acos(z1/(sqrt(x1*x1+y1*y1+z1*z1))))*180.0)/3.1416);

}


