#include<stdio.h>
#include<math.h>

 double area(int r)
{
    return 4*r*r-r*r*2*acos(0.0);
}

int main()
{
    int cs,cn=0;
    double r;
    scanf("%d",&cs);
    while(cs--)
    {
        scanf("%lf",&r);
        printf("Case %d: %llf\n",++cn,area(r));
    }
        return 0;
}
