#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main()
{
    srand(time(0));
    int i,lower=23,upper =80,count =10;
    for (i = 0; i < count; i++) {
        int num = (rand()%(upper - lower + 1)) + lower;
        printf("%d\n", num);
    }
    return 0;
}
