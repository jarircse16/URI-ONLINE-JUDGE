#include<stdio.h>

int main()
{
    int n;
    printf("Enter number of elements:");
    scanf("%d",&n);
    int a[n],i;
    printf("Enter array elements:");
    for(i=0;i<n;i++)
    {
        scanf("%d",&a[i]);
    }
    int sum=0;
    for(i=0;i<n;i++)
    {
        sum+=a[i];
    }
    printf("The sum is: %d",sum);
    return 0;

}

