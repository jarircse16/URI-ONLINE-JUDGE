
#include<stdio.h>

long long int power(long long int n,long long int p)
{
    if(p==0)
        return 1;
else{
    int i,result=1;
    for(i=0;i<p;i++)
    {
        result*=n;
    }
    return result;
}
}

long long int bintodec(long long int x)
{
    long long int i=0,sum=0,temp;
    while(x>0)
    {
        temp=x%10;
        sum=sum+temp*power(2,i);
        x=x/10;
        i++;
    }
    return sum;
}

long long int dectobin(long long int x)
{
    long long int i=1,sum=0,temp;
    while(x>0)
    {
        temp=x%2;
        sum+=temp*i;
        i*=10;
        x/=2;
    }
    return sum;
}


long long int dc(int x)
{
    int sum=0;
    while(x>0)
    {
        x=x/10;
        sum++;
    }
    return sum;
}

long long int swap(long long int x)
{
    return 11111111-x;
}

long long int tc(long long int x)
{
    long long int y=bintodec(x);
    long long int z=0-y;
    long long int q=dectobin(z);
    return q;


}

int main()
{
    long long int x,i;
    a:printf("Enter an eight bit binary number:");
    scanf("%llu",&x);
    if(dc(x)!=8)
        goto a;
    else
    {
        printf("1's compliment of the number: %llu is: ",x);
        for(i=0;i<8-dc(swap(x));i++){
            printf("0");
        }
        printf("%llu\n",swap(x));
    }
    //printf("2's compliment of the number: %llu is %llu",x,tc(x));

}
