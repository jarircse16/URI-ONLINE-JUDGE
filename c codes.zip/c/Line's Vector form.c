#include<stdio.h>

void main()
{
    int x1,x2,y1,y2,z1,z2;
    printf("Enter the co ordinates of 1st point,if 2D,enter 0 at 3rd position:");
    scanf("%d %d %d",&x1,&y1,&z1);
    printf("Enter the co ordinates of 2st point,if 2D,enter 0 at 3rd position:");
    scanf("%d %d %d",&x2,&y2,&z2);
    printf("The vector is %di+%dj+%dk",x2-x1,y2-y1,z2-z1);
}
