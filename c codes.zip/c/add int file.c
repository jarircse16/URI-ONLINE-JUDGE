#include<stdio.h>

int main()
{
    int a,b,sum;
    FILE *input,*output;
    input=fopen("input.txt","rb");
    output=fopen("output.txt","w+");
     while (fscanf(input,"%d %d",&a,&b)!= EOF)
    {
        printf("%d %d \n",a,b);
        sum=a+b;
        fprintf(output,"%d",&sum);

}printf("%d \n",sum);


}

