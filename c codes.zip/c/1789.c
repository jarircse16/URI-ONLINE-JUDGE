#include<stdio.h>

void fuck(int L)
{
    int a[L],i,max;
    for(i=0;i<L;i++)
    {
        scanf("%d",&a[i]);
    }
    max=a[0];
    for(i=1;i<L;i++)
    {
        if(a[i]>max)
        {
            max=a[i];
        }
    }
    if(max<10)
        printf("1\n");
    else if(max>10 && max<20)
        printf("2\n");
    else
        printf("3\n");

}


void main()
{

    int L;
    BT:scanf("%d",&L);
    while(1){
    if(L<1 || L>500)

        {
        break;
    }
    else
        {
        fuck(L);
        goto BT;
        }
}
}
