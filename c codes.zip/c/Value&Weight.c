#include<stdio.h>
typedef struct student
{
    int value,weight;
    char nam[30];
} goods;

int main()
{

    int cs,cn=0,i;
    scanf("%d",&cs);
    goods arms[cs];
    for(i=0;i<cs;i++)
    {
        printf("Enter arm name:");
        scanf("%s",arms[i].nam);
        printf("Enter value and weight:");
        scanf("%d %d",&arms[i].value,&arms[i].weight);

    }
    printf("Name--Weight--Value\n");
    for(i=0;i<cs;i++)
    {
        printf("%s %d %d\n",arms[i].nam,arms[i].weight,arms[i].value);

    }
    return 0;
    }



