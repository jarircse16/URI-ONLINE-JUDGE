#include<stdio.h>
#include<math.h>

void main()
{
    int a,b,c;
    printf("Enter three arms:");
    scanf("%d %d %d",&a,&b,&c);
    if(a+b>c && b+c>a && a+c>b)
    {
        printf("Angle A is: %llf degrees\n", acos((b*b*1.0+c*c*1.0-a*a*1.0)/(2*b*c*1.0))*180/3.1416);
        printf("Angle B is: %llf degrees\n", acos((c*c*1.0+a*a*1.0-b*b*1.0)/(2*a*c*1.0))*180/3.1416);
        printf("Angle C is: %llf degrees\n", acos((b*b*1.0+a*a*1.0-c*c*1.0)/(2*a*b*1.0))*180/3.1416);

    }
    else
    {
        printf("No triangle can be formed");
    }
}
