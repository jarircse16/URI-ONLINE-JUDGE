#include<stdio.h>
#include<string.h>

int main()
{
    char s1[20],s2[20],s3[20];
    scanf("%s",s1);
    scanf("%s",s2);
    scanf("%s",s3);
    if(strcmp(s1,"vertebrado")==0 && strcmp(s2,"ave")==0 && strcmp(s3,"carnivoro")==0)
        printf("aguia");
    else if(strcmp(s1,"vertebrado")==0 && strcmp(s2,"ave")==0 && strcmp(s3,"onivoro")==0)
        printf("pomba");
    else if(strcmp(s1,"vertebrado")==0 && strcmp(s2,"mamifero")==0 && strcmp(s3,"onivoro")==0)
        printf("homem");
    else if(strcmp(s1,"vertebrado")==0 && strcmp(s2,"mamifero")==0 && strcmp(s3,"herbivoro")==0)
        printf("vaca");
    else if(strcmp(s1,"invertebrado")==0 && strcmp(s2,"inseto")==0 && strcmp(s3,"hematofago")==0)
        printf("pulga");
    else if(strcmp(s1,"invertebrado")==0 && strcmp(s2,"inseto")==0 && strcmp(s3,"herbivoro")==0)
        printf("lagarta");
    else if(strcmp(s1,"invertebrado")==0 && strcmp(s2,"anelideo")==0 && strcmp(s3,"hematofogo")==0)
        printf("sanguessuga");
    else if(strcmp(s1,"invertebrado")==0 && strcmp(s2,"anelideo")==0 && strcmp(s3,"onivoro")==0)
        printf("minhoca");
    else
        printf("Error");
    return 0;

}
