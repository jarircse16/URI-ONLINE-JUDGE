#include<stdio.h>

void main()
{
    int X,Z,i,sum=0,c=0;
    scanf("%d",&X);
    while(1)
    {
        scanf("%d",&Z);
        if(Z>X)
            break;
    }
    for(i=X;i<Z;i++)
    {
        sum+=i;
        c++;
        if(sum>Z)
        {
            break;
        }
    }
    printf("%d\n",c);
}
