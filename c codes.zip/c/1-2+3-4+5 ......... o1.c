#include<stdio.h>

int main()
{
    int n,sum,i;
    printf("Enter the nth term:");
    scanf("%d",&n);
    if(n%2==0)
        sum=-n/2;
    else
        sum=(n-1)/2;
    printf("%d",sum);
    return 0;
}
