#include<stdio.h>
#include<math.h>

int parity(int n)
{
    long int temp,parity=0;
    while(n>0)
    {
        temp=n%2;
        parity+=temp;
        n=n/2;
    }
   if(parity%2==0)
    return 0;
   else
    return 1;
}
int main()
{
    int cs,cn=0,p,temp;
    scanf("%d",&cs);
    while(cs--)
    {

        scanf("%d",&p);
        if(parity(p)==1)
            printf("Case %d: odd\n",++cn);
        else
             printf("Case %d: even\n",++cn);
}


        return 0;
}
