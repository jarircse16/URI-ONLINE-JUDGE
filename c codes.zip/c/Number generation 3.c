#include<stdio.h>

void main()
{
     int a[10]={0,1,2,3,4,5,6,7,8,9},c3=0;
     int i,j,k,l,m;

     for(l=1;l<10;l++){
     for(l=1;l<10;l++){

     for(i=0;i<10;i++)
     {

        for(j=0;j<10;j++)

        {
            for(k=0;k<10;k++)

                {
//                printf("A number is %d",a[m]);
//                printf("%d",a[l]);
//                printf("%d",a[i]);
//                printf("%d",a[j]);
//                printf("%d\n",a[k]);
                c3++;
                }

                }

     }

     }


}
    printf("Total Numbers: %d",c3-1);
}

