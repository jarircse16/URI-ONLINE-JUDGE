#include<stdio.h>
#include<string.h>

int main()
{
    char x[99];
    gets(x);
    char y[99];
    int i,j=0,size=strlen(x);
    for(i=size-1;i>=0;i--)
    {
        y[j]=x[i];
        j++;
    }
    y[j]='\0';
    if(strcmp(x,y)==0)
        printf("Yes");
    else
        printf("No");
}
