#include<stdio.h>
#define Max 5
int stack[Max],top=-1;

int add(int item)
{
    if(top>=Max-1)
    {
        printf("Stack Full\n");
        return 0;
    }
    else
    {
        top++;
        stack[top]=item;
    }
}

int display()
{
    int i;
    if(top==-1)
    {
        printf("Stack Empty!\n");
        return 0;
    }
    else
    {
        printf("The stack is:");
        for(i=top;i>=0;i--)
        {
            printf("%d ",stack[i]);
        }
        printf("\n");
    }
    return 1;
}

int annihilate(int item)
{
    if(top<0)
    {
        printf("Stack Empty!");
        return 0;
    }
    else
    {
        item=stack[top];
        top--;
    }
    return 1;
}


int main()
{
    int ch,item;

    while(1)
    {
        printf("\n*** Stack Menu ***");
        printf("\n\n1.Push\n2.Pop\n3.Display\n4.Exit");
        printf("\n\nEnter your choice(1-4):");
        scanf("%d",&ch);

        switch(ch)
        {
            case 1: {

                printf("Enter a number to add:");
                scanf("%d",&item);
                add(item);
            }
                    break;
            case 2: {

                printf("Enter a number to remove:");
                scanf("%d",&item);
                annihilate(item);
            }
                    break;
            case 3: display();
                    break;
            case 4: return 0;

            default: printf("\nWrong Choice!!");
        }
    }
}
