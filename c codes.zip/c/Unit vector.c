#include<stdio.h>
#include<math.h>

#include<stdio.h>

void main()
{
    int x1,y1,z1;
    printf("Enter the components of vector:");
    scanf("%d %d %d",&x1,&y1,&z1);
    printf("The unit vector is: %lfi+%lfj+%lfk",x1/sqrt(x1*x1+y1*y1+z1*z1),y1/sqrt(x1*x1+y1*y1+z1*z1),z1/sqrt(x1*x1+y1*y1+z1*z1));
}


