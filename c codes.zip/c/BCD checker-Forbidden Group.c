#include<stdio.h>

long long int checker(long long int x)
{
    long long int i=0,temp,sum=0;
    while(x>0)
    {
        temp=x%10000;
        if(temp>1001)
            {
            i++;
        }
            x=x/10000;

    }
    if(i==0)
        return 1;
    else
        return 0;
}
int main()
{
    long long int x;
    printf("Enter a BCD to check:");
    scanf("%llu",&x);
    if(checker(x)==1)
        printf("Valid");
    else
        printf("Invalid");
    return 0;
}
