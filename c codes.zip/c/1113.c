#include<stdio.h>

void main()
{
    int b,c;
    while(1)
    {
        scanf("%d %d",&b,&c);
        if(b==c)
            break;
        if(b>c)
        {
           printf("Decrescente\n");
        }
        else
        {
            printf("Crescente\n");
        }
    }
}

