#include<stdio.h>

int gcd(int a,int b)
{
    int max,min;
    if(a>b)
    {
        max=a;
        min=b;
    }
    else
    {
        max=b;
        min=a;
    }
    if(max%min==0)
            return min;
    else
        return gcd(max%min,min);
}

int main()
{
    int a,b;
    ag:scanf("%d %d",&a,&b);
    if(a!=0 && b!=0){
    printf("%d",gcd(a,b));
}
    else
    {
        goto ag;
    }
    return 0;
}
