#include<stdio.h>
#include<math.h>
#include<stdlib.h>

 int gray2bin(int x)
{
     int b0,b1,b2,g0,g1,g2;

    g2=x/100;
    g1=(x/10)%10;
    g0=x%10;
    b2=g2;
    b1=abs(g2-g1);
    b0=abs(g2-g1-g0);
    printf("Binary Number:%d%d%d",b2,b1,b0);
    return 0;
}

int main()
{
    printf("Enter a gray code:");
    int x;
    scanf("%d",&x);
    gray2bin(x);
    return 0;
}

