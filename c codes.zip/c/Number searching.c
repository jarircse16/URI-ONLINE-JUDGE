#include<stdio.h>


int main()
{
    int n,t,count=0;
    printf("Enter the array size:");
    scanf("%d",&n);
    int a[n],i;
    printf("Enter the array:");
    for(i=0;i<n;i++)
    {
        scanf("%d",&a[i]);
    }
    printf("Enter the number to search:");
    scanf("%d",&t);
    for(i=0;i<n;i++)
    {
        if(a[i]==t)
            count++;
    }
    printf("%d is %d times found in the array.",t,count);
    return 0;
}
