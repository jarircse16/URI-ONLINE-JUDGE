#include<stdio.h>

void sum(int n)
{
        int i,sum=0;
        for(i=1;i<=n;i++)
        {
            if(i%2==1)
                sum++;
            else
                sum--;
        }
        printf("%d\n",sum);
}

void main()
{
    int T,n;
    scanf("%d",&T);
    while(T--)
    {
        scanf("%d",&n);
        sum(n);

    }

}
