#include<stdio.h>


int main()
{
    int n;
    printf("Enter the array size:");
    scanf("%d",&n);
    int a[n],i;
    printf("Enter the array:");
    for(i=0;i<n;i++)
    {
        scanf("%d",&a[i]);
    }
    int j,k,found=0;
    for(j=0;j<n;j++)
        for(k=j+1;k<n;k++)
    {
        if(a[j]==a[k]){
            found++;
    }
    }
    printf("%d duplicates found.",found);
    return 0;
}
