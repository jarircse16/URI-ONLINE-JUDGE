#include<stdio.h>

void main()
{
   int x;
   scanf("%d",&x);
   printf("%x",x);
}
