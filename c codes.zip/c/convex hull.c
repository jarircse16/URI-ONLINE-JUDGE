#include<stdio.h>
#include<math.h>

float angle(float a,float b,float c)
{
    float x=(a*a+c*c-b*b)*1.0,val=180/3.1416;
    return acos(x)*val;

}

struct point
{
    int x;
    int y;
};
int main()
{
    int n,i,c,d,swapx,swapy;
    printf("Enter number of points:");
    scanf("%d",&n);
    struct point points[n];
    printf("Enter the points:");
    for(i=0;i<n;i++)
    {
        scanf("%d %d",&points[i].x,&points[i].y);
    }
    printf("Before sorting:\n");
    printf("The points are:\n");
     for(i=0;i<n;i++)
    {
        printf("%d %d\n",points[i].x,points[i].y);
    }
/////////////////////Sort Function////////////////

        for (c = 0 ; c < 5; c++)
    {
        for (d = 0 ; d < 5 - c - 1; d++)
            {
                if (points[d].x > points[d+1].x)
                    {
                        swapx  = points[d].x;
                        swapy  = points[d].y;
                        points[d].x= points[d+1].x;
                        points[d].y= points[d+1].y;
                        points[d+1].x = swapx;
                        points[d+1].y=swapy;
                    }
            }
    }
    ///////////////////////////After sorting///////////////
    printf("After sorting:\n");
    printf("The points are:\n");
     for(i=0;i<n;i++)
    {
        printf("%d %d\n",points[i].x,points[i].y);
    }

    float a,b,c,ang[100];

    for(i=0;i<n;i++)
    {
        a=sqrt((points[i].x-points[i+1].x)*(points[i].x-points[i+1].x)+(points[i].y-points[i+1].y)*(points[i].y-points[i+1].y));
        b=sqrt((points[i].x-points[i+2].x)*(points[i].x-points[i+2].x)+(points[i].y-points[i+2].y)*(points[i].y-points[i+2].y));
        c=sqrt((points[i+2].x-points[i+1].x)*(points[i+2].x-points[i+1].x)+(points[i+2].y-points[i+1].y)*(points[i+2].y-points[i+1].y));
        if(angle(a,b,c))
    }



}
