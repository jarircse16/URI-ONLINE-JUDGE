#include<stdio.h>
#include<math.h>
#include<stdlib.h>
int lift(int myp,int lp)
{
    return (abs(myp-lp))*4+3+5+3+(myp-0)*4+5+3;
}

int main()
{
    int cs,cn=0,myp,lp;
    scanf("%d",&cs);

    while(cs--)
    {
        scanf("%d %d",&myp,&lp);
        printf("Case %d: %d\n",++cn,lift(myp,lp));
    }
        return 0;
}

