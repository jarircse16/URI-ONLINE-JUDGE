#include<stdio.h>

void main()
{
    int i,n,sum1=0,sum2=0,m=1;
    scanf("%d",&n);
    for(i=1;i<=n;i++)
    {
        sum1+=i*(n-i+1);
    }
    printf("Left Hand Side:%d\n ",sum1);

    while(1)
    {
        if(n==0)
            break;
        sum2+=m*n;
        m++;
        n--;
    }
    printf("Right Hand Side:%d\n ",sum2);


}
