#include<stdio.h>
int main()
{
    long long int n,i,j,k,count=0,b;
    scanf("%lld",&n);
    long long int l,r,county=0;
    for(i=0;i<n;i++)
    {
        scanf("%lld %lld",&l,&r);
        for(j=l;j<=r;j++){
            for(k=1;k<=j;k++){
                if(j%k==0 && k%2!=0){
                count++;
                }
            }
            if(count%2!=0){
            county++;
            count=0;
            }
        }
    printf("case %lld: %lld\n",i+1,county);
    county=0;
    }
    return 0;
}
