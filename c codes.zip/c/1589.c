#include<stdio.h>
void main()
{
    int T,r1,r2;
    scanf("%d",&T);
    while(T--)
    {
        scanf("%d %d",&r1,&r2);
        printf("%d\n",r1+r2);
    }
}
