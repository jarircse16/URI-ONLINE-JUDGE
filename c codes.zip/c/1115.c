#include<stdio.h>

void main()
{
    int b,c;
    while(1)
    {
        scanf("%d %d",&b,&c);
        if(b>0 && c>0)
        {
           printf("primeiro\n");
        }
        else if(b>0 && c<0)
        {
            printf("quarto\n");
        }
        else if(b<0 && c<0)
        {
            printf("terceiro\n");
        }
        else if(b<0 && c>0)
        {
            printf("segundo\n");
        }
        else
            break;
    }
}
