#include<stdio.h>

void main()
{
    int x[10],i,d;
    scanf("%d",&d);
    x[0]=d;
    for(i=1;i<10;i++)
    {
        x[i]=d*2;
        d*=2;
    }
    for(i=0;i<10;i++)
    {
        printf("N[%d] = %d\n",i,x[i]);
    }
}
