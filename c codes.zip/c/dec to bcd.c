#include<stdio.h>

long long int rever(int x)
{
    long long int reverse=0;
    while(x!=0)
    {
        reverse=reverse *10;
        reverse=reverse +x%10;
        x=x/10;
    }
    return reverse;
}

long long int dectobin(long long int x)
{
    long long int i=1,sum=0,temp;
    while(x>0)
    {
        temp=x%2;
        sum+=temp*i;
        i*=10;
        x/=2;
    }
    return sum;
}


long long int dectobcd(long long int x)
{
        long long int p,i=0,digit,count=0;
        while(x>0)
        {
            digit=x%10;
            count++;
            if(digit<8)
            {
            printf("0");
            printf("%d",dectobin(digit));
            }
            else
            {
            printf("%d",dectobin(digit));
            }
            x=x/10;
        }
}

int main()
{
    int n;
    printf("Decimal to BCD Converter.\n");
    printf("Enter a number to convert:");
    scanf("%d",&n);
    printf("The BCD output is:");
    dectobcd(rever(n));
    return 0;
}
