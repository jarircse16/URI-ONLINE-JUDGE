#include<stdio.h>

void main()
{
    int T;
    scanf("%d",&T);
    int a,b,c,d,e,sum=0;
    for(a=1;a<=T;a++)
    {
        scanf("%d %d",&b,&c);
        sum=0;
        if(b>c)
        {
            d=c+1;
            e=b;
        }
        else
        {
            d=b+1;
            e=c;
        }
        for(;d<e;d++)
        {
            if(d%2==1 || d%2==-1)
                sum+=d;
        }
        printf("%d\n",sum);
    }


}
