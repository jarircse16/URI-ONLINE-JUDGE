#include<stdio.h>

void main()
{
    int i,*ptr,odd[5]={1,3,5,7,9};
    ptr=odd; /*for any array,the address of it's 1st element is it's address*/
    for(i=0;i<5;i++)
    {
        printf("%d ",*ptr);
        ptr++;
    }
}
