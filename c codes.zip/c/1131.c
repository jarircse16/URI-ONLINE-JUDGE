#include<stdio.h>

void main()
{
    int a,b,count=0,iv=0,gv=0,ev=0,p;
while(1){

CON:scanf("%d %d",&a,&b);
                    count++;
                    if(a>b)
                        iv++;
                    else if(a<b)
                        gv++;
                    else
                        ev++;
BX: printf("novo calculo (1-sim 2-nao)\n");
    scanf("%d",&p);
    switch(p)
        {
        case 1:

            goto CON;
        case 2:{
            printf("%d grenais\n",count);
            printf("Inter:%d\n",iv);
            printf("Gremio:%d\n",gv);
            printf("Empates:%d\n",ev);
            if(iv>gv)
                printf("Inter venceu mais\n");
            else if(iv<gv)
                printf("Gremio venceu mais\n");
            else
                printf("N�o houve vencedor\n");
             break;
        }
        default:
            {
                goto BX;
            }


        }

}

}
