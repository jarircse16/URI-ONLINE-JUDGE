#include<stdio.h>

void main()
{
    float av,b,vs,vo,vf;
    int i;
    printf("Enter amplifier gain,feedback gain,initial voltage,iterations:");
    scanf("%f %f %f &f",&av,&b,&vs,&i);
    while(i--)
    {
        vo=av*vs;
        vf=b*vo;
    }
    if(vs==vf)
        printf("Stable\nClosed Loop Gain=%f",av*b);
    else
        printf("UnStable\nClosed Loop Gain=%f",av*b);
}
