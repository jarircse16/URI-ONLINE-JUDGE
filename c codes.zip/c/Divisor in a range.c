#include<stdio.h>

void divi(int n)
{
    printf("1 is a divisor");
}
