#include<stdio.h>

void main()
{
     int a[6]={0,5,6,7,8,9},c1=0,c2=0,c3=0;
     int i,j,k;
     for(i=1;i<=5;i++)
     {
         printf("A number is %d\n",a[i]);
         c1++;

     }

    i=0;
    for(i=1;i<6;i++)
     {

          for(j=0;j<6;j++)
     {
         printf("A number is %d",a[i]);
         printf("%d\n",a[j]);
         c2++;

     }
     }


     i=0;
     for(i=1;i<6;i++)
     {

        for(j=0;j<6;j++)

        {
            for(k=0;k<6;k++)

                {
                printf("A number is %d",a[i]);
                printf("%d",a[j]);
                printf("%d\n",a[k]);
                c3++;

                }

     }

     }
     printf("Total Numbers: %d",c1+c2+c3);

}

