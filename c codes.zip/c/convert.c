#include<stdio.h>

float convert(float dollars)
{

    return 2.0*dollars;
}


int main()
{
    float dollars;
    printf("Enter an amount:");
    scanf("%f",&dollars);
    float pounds;
    pounds=convert(dollars);
    printf("%f",pounds);
    return 0;
}
