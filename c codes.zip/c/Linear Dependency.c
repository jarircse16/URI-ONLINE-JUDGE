#include<stdio.h>
#include<math.h>

void main()
{
    int a1,a2,a3,b1,b2,b3,c1,c2,c3;
    printf("Enter 1st vector's i,j,k components:");
    scanf("%d %d %d",&a1,&b1,&c1);
    printf("Enter 2nd vector's i,j,k components:");
    scanf("%d %d %d",&a2,&b2,&c2);
    printf("Enter 3rd vector's i,j,k components:");
    scanf("%d %d %d",&a3,&b3,&c3);
    if((a1*(b2*c3-b3*c2)-b1*(a2*c3-a3*c2)+c1*(a2*b3-a3*b2))==0)
        printf("Linearly dependent");
    else
        printf("Linearly independent");
}
