#include<stdio.h>

void main()
{
    float a=10.375;
    char *ptr;
    ptr=(char *)&a;
    printf("ptr *ptr\n");
    printf("---- ----\n");
    printf("%x %02x\n",ptr,*ptr);
    ++ptr;
    printf("%x %02x\n",ptr,*ptr);
    ++ptr;
    printf("%x %02x\n",ptr,*ptr);
    ++ptr;
    printf("%x %02x\n",ptr,*ptr);
}
