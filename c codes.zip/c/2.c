#include<stdio.h>

int main()
{
    int n;
    printf("Enter number of elements:");
    scanf("%d",&n);
    int a[n],i;
    printf("Enter array elements:");
    for(i=0;i<n;i++)
    {
        scanf("%d",&a[i]);
    }
    printf("The negative elements are:");
    for(i=0;i<n;i++)
    {
        if(a[i]<0)
        printf("%d ",a[i]);
    }
    return 0;
}

