#include<stdio.h>
#include<math.h>

int onoroy(int n)
{
    long int temp,onoroy=0;
    while(n>0)
    {
        temp=n%2;
        onoroy+=temp;
        n=n/2;
    }
    return onoroy;
}
int main()
{
    int cs,cn=0,o,temp;
    scanf("%d",&cs);
    while(cs--)
    {
        scanf("%d",&o);
        temp=o;
        while(1)
        {
            temp++;
            if(onoroy(o)==onoroy(temp))
            {
                printf("Case %d: %d\n",++cn,temp);
                break;
            }


        }

    }
        return 0;
}
