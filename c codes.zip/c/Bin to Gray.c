#include<stdio.h>
#include<math.h>
#include<stdlib.h>

 int bin2gray(int x)
{
     int b0,b1,b2,g0,g1,g2;

    b2=x/100;
    b1=(x/10)%10;
    b0=x%10;
    g2=b2;
    g1=abs(b2-b1);
    g0=abs(b1-b0);
    printf("Gray code:%d%d%d",g2,g1,g0);
    return 0;
}

int main()
{
    printf("Enter a binary number:");
    int x;
    scanf("%d",&x);
    bin2gray(x);
    return 0;
}
