#include<stdio.h>
#include<math.h>

void main()
{
    int u,v,a;
    printf("Enter boat speed and tide speed Serially:");
    scanf("%d %d",&v,&u);\
    printf("Boat angle: %lf",((acos(-u/v))*180)/3.1416);
}
