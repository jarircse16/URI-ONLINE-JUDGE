
#include<stdio.h>

void main()
{
        int i;
        char sentence[1000];
        FILE *fptr;
        fptr = fopen("program.txt", "w");
   if(fptr == NULL)
   {
      printf("Error!");
   }

    for(i=0;i<1000;i++)
    {
        if(i<10)
         fprintf(fptr,"00%d\n", i);
        else if(i<100)
             fprintf(fptr,"0%d\n", i);
         else
             fprintf(fptr,"%d\n", i);
    }
     fclose(fptr);

}





