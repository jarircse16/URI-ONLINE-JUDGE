#include<stdio.h>

void main()
{
    int N,b,c,i;
    scanf("%d",&N);
    for(i=1;i<=N;i++)
    {
        scanf("%d %d",&b,&c);
        if(c==0)
            printf("divisao impossivel\n");
        else
            printf("%.1f\n",(b*1.0)/(c*1.0));
    }
}
