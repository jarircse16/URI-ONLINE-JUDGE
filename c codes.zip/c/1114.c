#include<stdio.h>

void main()
{
    int b;
    while(1)
    {
        scanf("%d",&b);
        if(b==2002)
        {
            printf("Acesso Permitido\n");
             break;
        }
        else
        {
            printf("Senha Invalida\n");
            continue;
        }
    }
}


