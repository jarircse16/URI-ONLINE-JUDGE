#include<stdio.h>
int main(void)
{
    char ch='n';
    int i,x=300;
    float y=10.375;
    double z=99.99;
    char *chPtr;
    void *ptr;
    chPtr=(char *)&ptr;
    for(i=0;i<18;i++)
    {
        printf("Address= %x Data=%02x\n",chPtr++,(unsigned char)*chPtr);

    }
    printf("\nAt the Beginning: ptr=%02x\n",&ptr,ptr);
    ptr=&ch;
    printf("\n After ptr=&ch:\n");
    printf("ptr=%x *ptr=%02x\n",ptr,*(char *)ptr);
    ptr=&x;
    printf("\nAfter ptr=&x:\n");
    printf("ptr=%x *ptr=%04x\n",ptr,*(int *)ptr);
    ptr=&y;
    printf("\nAfter ptr=&y:\n");
    printf("ptr=%x *ptr=%g\n",ptr,*(float *)ptr);
    ptr=&z;
    printf("\nAfter ptr=&x:\n");
    printf("ptr=%x *ptr=%04x\n",ptr,*(double *)ptr);

}
