#include<stdio.h>
#include<math.h>

int s(int n)
{
    int sum=0;
    while(n)
    {
        sum+=n;
        n--;
    }
    return sum;
}

int by3(int a,int b)
{
    int i,c=0;
    for(i=a;i<=b;i++)
    {
        if(s(i)%3==0)
            c++;
    }
    return c;
}
void main()
{
    int cs,cn=0,a,b;
    scanf("%d",&cs);
    while(cs--)
    {
        scanf("%d %d",&a,&b);
        printf("Case %d: %d\n",++cn,by3(a,b));
    }

}
