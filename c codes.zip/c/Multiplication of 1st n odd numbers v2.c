#include<stdio.h>

void main()
{
    int i,n;
    long long result=1,count=0;
    scanf("%d",&n);
    for(i=1;;)
    {
        result*=i;
        i+=2;
        count++;
        if(count==n)
            break;
    }
    printf("The result is %lld",result);

}
