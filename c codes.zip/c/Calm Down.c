#include<stdio.h>
#include<math.h>
#define pi acos(-1)

 double radius(double R,int n)
{
    double x=sin(pi/n);
    double r=(R*x)/(1+x);
    return r;
}

int main()
{
    int cs,cn=0,n;
    double R;
    scanf("%d",&cs);

    while(cs--)
    {
        scanf("%lf %d",&R,&n);
        printf("Case %d: %llf\n",++cn,radius(R,n));
    }
        return 0;
}
