#include<stdio.h>
#include<math.h>

void main()
{
    int x1,x2,y1,y2,z1,z2;
    printf("Enter the components of vector to be projected:");
    scanf("%d %d %d",&x1,&y1,&z1);
    printf("Enter the components of vector on which projection will take place:");
    scanf("%d %d %d",&x2,&y2,&z2);
    printf("Projection is: %lf",(x1*x2*1.0+y1*y2*1.0+z1*z2*1.0)/sqrt(x2*x2*1.0+y2*y2*1.0+z2*z2*1.0));
}


