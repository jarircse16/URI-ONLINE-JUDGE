#include<stdio.h>
#include<math.h>
#include<time.h>
#include<stdlib.h>

float random()
{
   return(rand()%100);
}

void main()
{
    srand(time(NULL));
    float cf,c,av,pi=acos(-1);
    printf("Enter Cutoff frequency,Capacitance,Gain:");
    scanf("%f %f %f",&cf,&c,&av);
    float R=1/(2*pi*cf*c);
    float R1=random();
    float Rf=(av-1)*R1;
    printf("R= %f\nR1=%f\nRf=%f\n",R,R1,Rf);
}
