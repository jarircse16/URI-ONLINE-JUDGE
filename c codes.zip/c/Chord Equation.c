#include<stdio.h>

void main()
{
    int h,k,r;
    printf("Enter the center:");
    scanf("%d %d",&h,&k);
    printf("Enter radius:");
    scanf("%d",&r);
    int c=h*h+k*k-r*r;
    printf("The circle equation is: x^2+y^2+%dx+%dy+%d=0.\n",-2*h,-2*k,c);
    int a,b;
    printf("Enter middle point of the chord:");
    scanf("%d %d",&a,&b);
    if(a*a+b*b-2*h*a-2*k*b+c>0 || a*a+b*b-2*h*a-2*k*b+c==0)
        printf("This wont form chord");
    else
        printf("Chord Equation is: x^2+y^2+%dx+%dy+%d=%dx+%dy+%d(x+%d)+%d(y+%d)+%d=0",-2*h,-2*k,c,a,b,-2*h,a,-2*k,b,c);
}
