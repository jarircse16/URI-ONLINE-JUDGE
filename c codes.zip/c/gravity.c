#include<stdio.h>

int main()
{
    int x1,x2,x3,y1,y2,y3;
    printf("Enter 3 climaxes serially:");
    scanf("%d %d %d %d %d %d",&x1,&y1,&x2,&y2,&x3,&y3);
    if((x1*y2+x2*y3+x3*y1-x1*y3-x3*y2-x2*y1)==0)
        printf("Can't form a triangle");
    else
        printf("The gravity is (%f,%f)",(x1+x2+x3)/3.0,(y2+y3+y1)/3.0);
    return 0;
}

