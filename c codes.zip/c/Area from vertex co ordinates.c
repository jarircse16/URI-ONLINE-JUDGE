#include<stdio.h>

int main()
{
    int x1,x2,x3,y1,y2,y3;
    float area;
    printf("Enter x and y for 3 vertices serially x1 y1 x2 y2 x3 y3:");
    scanf("%d %d %d %d %d %d ",&x1,&y1,&x2,&y2,&x3,&y3);
    area=0.5*(x1*y2+x2*y3+x3*y1-x1*y3-x3*y2-x2*y1);
    if(area==0)
        printf("These points are on the same line and can't form a triangle");
    else
        printf("The area is: %f",area);
        return 0;
}
