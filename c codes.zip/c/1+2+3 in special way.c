#include<stdio.h>

int f(int n)
{
    if(n==0)
        return 0;
    else
        return n+f(n-1);
}

void main()
{
    int n,fn;
    printf("Enter the nth term:");
    scanf("%d",&n);
    fn=f(n);
    printf("Sum= %d",(fn*(fn+1))/2);
    printf("Sum= %d",(x*x-x)/2);
}
