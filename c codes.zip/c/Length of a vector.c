#include<stdio.h>
#include<math.h>

void main()
{
    int x1,y1,z1;
    printf("Enter the components of 1st vector:");
    scanf("%d %d %d",&x1,&y1,&z1);
    printf("Length is : %lf",sqrt(x1*x1*1.0+y1*y1*1.0+z1*z1*1.0));
}
