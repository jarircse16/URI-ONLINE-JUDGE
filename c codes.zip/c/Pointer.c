#include<stdio.h>

void main()
{
    int id=44;
    float gpa=3.87;
    float cgpa=3.78;
    printf("Address of id is %x.\n",&id);
    printf("Address of gpa is %x.\n",&gpa);
    printf("Address of cgpa is %x.\n",&cgpa);
}
