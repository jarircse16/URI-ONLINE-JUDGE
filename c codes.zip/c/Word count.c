#include<stdio.h>
#include<string.h>

int main()
{
    int i,c=0;
    char x[1000];
    printf("Enter sentence:");
    gets(x);
    for(i=1;x[i]!='\0';i++)
    {
        if(x[i]==' ')
            c++;
    }
    printf("Word count= %d",c+1);
    return 0;

}

