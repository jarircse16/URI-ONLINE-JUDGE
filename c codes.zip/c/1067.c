#include<stdio.h>

void main()
{
    int c,i;
    scanf("%d",&c);
    for(i=1;i<=c;i+=2)
    {
        printf("%d\n",i);
    }
}
