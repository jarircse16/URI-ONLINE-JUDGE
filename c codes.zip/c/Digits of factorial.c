#include<stdio.h>
#include<math.h>

int base(int ba,long int d)
{
    if(d==0)
        return 1;
    else
        {
    long int b=0,temp,i=1;
    double dc=0;
    for(i=1;i<=d;i++)
    {
        dc+=(log(i)/log(ba));
    }
    return ceil(dc);
}
}

int main() //22 input dile prb dicche :3
{
    int cs,ba,cc=0;
    long int d;
    scanf("%d",&cs);
    while(cs--)
    {
        scanf("%lld %d",&d,&ba);
        cc++;
        int dc=base(ba,d);
        printf("Case %d: %d\n",cc,dc);
    }
        return 0;
}
