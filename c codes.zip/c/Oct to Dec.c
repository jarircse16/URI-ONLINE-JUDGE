#include<stdio.h>
int power(int n ,int p)
{
    int i,power=1;
    for(i=1;i<=p;i++)
    {
        power*=n;
    }
    return power;
}

void main()
{
    int b,temp,p=0,d=0;
    scanf("%d",&b);
    while(b>0)
    {
        temp=b%10;
        d+=temp*power(8,p);
        b=b/10;
        p++;
    }
    printf("%d",d);


}
