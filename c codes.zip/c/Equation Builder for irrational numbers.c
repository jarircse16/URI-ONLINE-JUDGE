#include<stdio.h>
#include<math.h>
int main()
{
    int s;
    double f,a;
    printf("Enter roots like a+sqr(b) or a-sqr(b) to build equation with it's conjugate.");
    printf("\n");
    printf("Enter solid and fraction part serially:");
    scanf("%d %lf",&s,&a);
    f=sqrt(a);
    printf("The equation is x*x-%dx+%.2lf",2*s,(pow(s,2)-a));

}
