#include<stdio.h>

long long int power(long long int n,long long int p)
{
    if(p==0)
        return 1;
else{
    int i,result=1;
    for(i=0;i<p;i++)
    {
        result*=n;
    }
    return result;
}
}

long long int bintodec(long long int x)
{
    long long int i=0,sum=0,temp;
    while(x>0)
    {
        temp=x%10;
        sum=sum+temp*power(2,i);
        x=x/10;
        i++;
    }
    return sum;
}

long long int dectobin(long long int x)
{
    long long int i=1,sum=0,temp;
    while(x>0)
    {
        temp=x%2;
        sum+=temp*i;
        i*=10;
        x/=2;
    }
    return sum;
}


int main()
{
    long long int a,b,sum,diff,mul,div,rem;
    printf("Enter two binary numbers(Greater number first):");
    scanf("%llu %llu",&a,&b);
    sum=bintodec(a)+bintodec(b);
    diff=bintodec(a)-bintodec(b); //can't print negative results
    mul=bintodec(a)*bintodec(b);
    div=bintodec(a)/bintodec(b);
    rem=bintodec(a)%bintodec(b);
    printf("Summation=%llu\n",dectobin(sum));
    printf("Subtraction=%llu\n",dectobin(diff));
    printf("Multiplication=%llu\n",dectobin(mul));
    printf("Division=%llu\n",dectobin(div));
    printf("Remainder=%llu\n",dectobin(rem));
    return 0;
}
