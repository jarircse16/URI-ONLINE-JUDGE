#include<stdio.h>
#include<math.h>
#include<stdlib.h>

void main()
{
    printf("%f",log(10));
}
