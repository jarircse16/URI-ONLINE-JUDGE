#include<stdio.h>
#include<string.h>

int a[]={1,1,1,1,0,0,1,1,1,1,1,1,1,0,0,0,0,0,1,1,1,0,0,1,0};
int DP[100];

int dp(int i)
{
    if(a[i]==1)
        return dp(i+1)+1;
    else
}
void main()
{
    printf("%d",dp(0,0,sizeof(a)/sizeof(a[0])));
}
