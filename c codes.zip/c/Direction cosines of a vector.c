#include<stdio.h>
#include<math.h>

void main()
{
    int x1,y1,z1;
    printf("Enter the components of 1st vector:");
    scanf("%d %d %d",&x1,&y1,&z1);
    printf("Direction Cosine with x-axis is: %lf \n",x1/(sqrt(x1*x1+y1*y1+z1*z1)));
    printf("Direction Cosine with y-axis is: %lf \n",y1/(sqrt(x1*x1+y1*y1+z1*z1)));
    printf("Direction Cosine with z-axis is: %lf \n",z1/(sqrt(x1*x1+y1*y1+z1*z1)));

}



