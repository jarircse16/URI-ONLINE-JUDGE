#include<stdio.h>

void main()
{

    double i,j,sum=0.0;
    for(i=1,j=1;i<=39;i+=2,j*=2)
    {

        sum=sum+i/j;

    }
    printf("%.2f\n",sum);

}
