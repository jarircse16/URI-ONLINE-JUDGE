#include<stdio.h>
#include<stdlib.h>

int random()
{
    return rand()%100;
}

void main()
{
    printf("%d",random());
}
