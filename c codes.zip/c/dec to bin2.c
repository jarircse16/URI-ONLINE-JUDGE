#include<stdio.h>

void put(int x)
{
    if(x>9)
        printf("%c",'A'+x-10);
    else
        printf("%d",x);
}

int tobin(int n,int base)
{
    if(n==0)
        printf("0");
    else
    {
        tobin(n/base,base);
        put(n%base);
    }
}

void main ()
{
    tobin(123467,256);
}
