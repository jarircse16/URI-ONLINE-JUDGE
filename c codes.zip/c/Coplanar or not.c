#include<stdio.h>


void main()
{
    int x1,x2,y1,y2,z1,z2,x3,y3,z3;
    printf("Enter the components of 1st vector:");
    scanf("%d %d %d",&x1,&y1,&z1);
    printf("Enter the components of 2nd vector:");
    scanf("%d %d %d",&x2,&y2,&z2);
    printf("Enter the components of 3rd vector:");
    scanf("%d %d %d",&x3,&y3,&z3);
    if((y1*z2-y2*z1)*x3+(z1*x2-z2*x1)*y3+(x1*y2-x2*y1)*z3==0)
        printf("Co-planer");
    else
        printf("Non-planer");

}


