#include<stdio.h>

unsigned long long power(unsigned long long a,unsigned long long p)
{
    if(p)
    {
        return a*power(a,p-1);
    }
    return 1;
}

unsigned long long a2n(unsigned long long a,unsigned long long n)
{
    unsigned long long y=power(2,n);
    if(y)
    {
        return a*power(a,y-1);
    }
    return 1;
}
void main()
{
    unsigned long long n,a;
    scanf("%llu %llu",&a,&n);
    printf("%llu",a2n(a,n));
}
