#include<stdio.h>

int main() {
 int num1,num2,i;
 printf("Enter two numbers:");
 scanf("%d %d",&num1,&num2);

 while (num2--) {
 num1++;
 }

 printf("Sum is : %d", num1);
 return (0);
}

