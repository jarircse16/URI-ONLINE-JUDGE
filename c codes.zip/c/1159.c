#include<stdio.h>

void reptile(int x)
{
    int k,sum=0,c=0;

        if(x%2==0)
            x+=0;
        else
            x++;
        for(k=x;;k+=2)
        {
            sum+=k;
            c++;
            if(c==5)
                break;
        }

        printf("%d\n",sum);
}

void main()
{
    int x;
    while(1)
    {
        BT:scanf("%d",&x);
        if(x==0)
            break;
        else{

                reptile(x);
                goto BT;
        }


    }


    }

