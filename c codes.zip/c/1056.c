#include<stdio.h>
#include<string.h>




int main()
{
    int a[]={2,3,4,5},b[]={6,7,8,9},i,j,c;
    for(i=0;i<4;i++)
    {
        for(j=0;j<4;j++)
        {
            if(b[j]%a[i]==0)
               for(c=i-1;c<3;c++)
               {
                a[c] = a[c+1];
               }
        }
    }
    for(i=0;i<4;i++)
    {
        printf("%d\n",a[i]);
    }
    return 0;
}
