#include<stdio.h>
#include<math.h>
//use 20 iterations
long long facti(int n)
{
    int i,fact=1;
    for(i=1;i<=n;i++)
    {
        fact=fact*i;
    }
    if(n==0 || n==1)
        return 1;
    else
        return n*facti(n-1);
}

int main()
{
    int n,i;
    double sum=0.0,x,p;
    printf("Enter number of iterations:");
    scanf("%d",&n);
    printf("Enter the value of x  for sinx:");
    scanf("%lf",&x);
    for(i=0;i<n;i++)
    {
        if(i%2==0)
            p=0;
        else if(i%2==1 && i%4==1)
            p=1;
        else
            p=-1;
        sum=sum+(pow(x,i)*p/facti(i));
    }
    printf("Value of sinx for %d iterations is %lf",i,sqrt(1+sum));
}

