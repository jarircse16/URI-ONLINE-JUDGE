
#include <stdio.h>

int main()
{
    int num;
    while(scanf("%d", &num)!=EOF)
        printf("%d\n", num - 1);
    return 0;
}
