#include<stdio.h>
#include<math.h>
long long facti(int n)
{
    int i,fact=1;
    for(i=1;i<=n;i++)
    {
        fact=fact*i;
    }
    if(n==0 || n==1)
        return 1;
    else
        return n*facti(n-1);
}
void main()
{
     long long x=5;
    printf("%lld\n",facti(x));
    printf("%llf",log(10));
}
