#include<stdio.h>

void main()
{
    int age,sum=0,c=0;
    float avg;
    while(1)
    {
        scanf("%d",&age);
        if(age<0)
            {
            break;
            }
            else
                {
            sum+=age;
            c++;
                }
        }
        avg=(sum*1.0)/(c*1.0);
        printf("%.2f\n",avg);
}
