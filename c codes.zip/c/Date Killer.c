#include<stdio.h>
#include<string.h>

int main()
{
    int i,c=0;
    char x[10];
    printf("Enter Date in dd/mm/yyyy or dd-mm-yyyy or dd.mm.yyyy format:");
    gets(x);
    for(i=1;;i++)
    {
        if(x[i]=='/' || x[i]=='-' || x[i]=='.')
            {
                printf("Date is %c%c\n",x[i-2],x[i-1]);
                break;
            }
    }
    for(i=i+1;;i++)
    {
         if(x[i]=='/' || x[i]=='-' || x[i]=='.')
            {
                printf("Month is %c%c\n",x[i-2],x[i-1]);
                break;
            }

    }
    i++;
    printf("Year is:");
    for(;x[i]!='\0';i++)
    {
        printf("%c",x[i]);
    }
    return 0;

}

