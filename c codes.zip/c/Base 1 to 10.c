#include<stdio.h>

void main()
{
    int base;
    printf("Enter Base:");
    scanf("%d",&base);
    long int b=0,d,temp,i=1;
    printf("Enter Decimal Number:");
    scanf("%ld",&d);
    while(d>0)
    {
        temp=d%base;
        b+=temp*i;
        d=d/base;
        i=i*10;
    }
    printf("%d",b);
}
