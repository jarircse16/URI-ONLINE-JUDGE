#include<stdio.h>

int main()
{
    int ox=0,oy=0,x,y;
    printf("Enter the point:");
    scanf("%d %d",&x,&y);
    printf("The Default point with respect to (%d,%d) is (%d,%d).\n",ox,oy,x-ox,y-oy);
    printf("Enter the new origin:");
    scanf("%d %d",&ox,&oy);
    printf("The Default point with respect to (%d,%d) is (%d,%d).\n",ox,oy,x-ox,y-oy);

}
