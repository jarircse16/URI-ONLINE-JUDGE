#include<stdio.h>
#include<math.h>
#include<stdlib.h>

void ekkadokka(int w)
{
    int m=1,n=1,i;
    if(w%2==1){
        printf("Impossible");
        }
    else{
        while(w%2==0)
    {
        w=w/2;
        m=m*2;
    }
        n=n*w;
        if(n==1)
            printf("Impossible");
        else
            printf("%d %d",n,m);
}

}

int main()
{
    int cs,w,cn=0;
    scanf("%d",&cs);
    while(cs--)
    {

        scanf("%d",&w);
        printf("Case %d: ",++cn);
        ekkadokka(w);
        printf("\n");
    }
    return 0;
}
