#include<stdio.h>


int of(int x)
{
    int i,count;
    for(i=1;i<=x;i++)
    {
        if(x%i==0 && i%2!=0)
            count++;
    }
    if(count%2!=0)
        return count;
    else
        return 0;
}

int main()
{
    int L,R,i;
    printf("Enter low and high limit:");
    scanf("%d %d",&L,&R);
    for(i=L;i<R+1;i++)
    {
        if(of(i)!=0)
            printf("Odd factor count:%d\n",of(i));
        else
            printf("Odd factorization not possible\n");
    }
}
