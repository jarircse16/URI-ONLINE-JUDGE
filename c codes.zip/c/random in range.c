#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main()
{
    srand(time(0));
    int i,lower=23,upper =80,count =10,num;
    for (i = 0; i < count;) {
        abc:num = (rand()%(upper));
        if(num<23)
        {
            goto abc;
        }
        else
        {

            printf("%d\n", num);
            i++;
        }
        }
    }
    return 0;
}

