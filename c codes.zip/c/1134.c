#include<stdio.h>

void main()
{
    int a=0,d=0,g=0,i;
    BT:scanf("%d",&i);
    while(1)
    {
        if(i==1)
            {
                a++;
                goto BT;
            }
        else if(i==2)
            {
                g++;
                goto BT;
            }
        else if(i==3)
            {
                d++;
                goto BT;
            }
        else if(i==4)
            break;
        else
            goto BT;
    }
    printf("MUITO OBRIGADO\n");
    printf("Alcool: %d\n",a);
    printf("Gasolina: %d\n",g);
    printf("Diesel: %d\n",d);
}
