#include<stdio.h>

void main()
{
    int a,b;
    scanf("%d %d",&a ,&b);
    printf("%d\n%d",a%b,b%a);
}
