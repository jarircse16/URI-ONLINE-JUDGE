#include<stdio.h>

int main()
{
    int a[10],small,i;
    printf("Enter 10 numbers:\n");
    for(i=0;i<10;i++)
    {
        scanf("%d",&a[i]);
    }
    small=a[0];
    for(i=1;i<10;i++)
    {
        if(a[i]<small)
        {
            small=a[i];
        }
    }
    printf("Smallest: %d",small);
    return 0;
}
