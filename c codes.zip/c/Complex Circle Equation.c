#include<stdio.h>

void main()
{
    int h,k,r;
    printf("Enter the center:");
    scanf("%d %d",&h,&k);
    printf("Enter radius:");
    scanf("%d",&r);
    int c=h*h+k*k-r*r;
    printf("The circle equation is: x^2+y^2+%dx+%dy+%d=0.",-2*h,-2*k,c);

}
