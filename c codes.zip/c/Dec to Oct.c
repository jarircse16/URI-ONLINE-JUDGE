#include<stdio.h>

void main()
{
    long int b=0,d,temp,i=1;
    scanf("%ld",&d);
    while(d>0)
    {
        temp=d%8;
        b+=temp*i;
        d=d/8;
        i=i*10;
    }
    printf("%d",b);
}
