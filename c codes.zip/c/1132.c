#include<stdio.h>

void main()
{
    int X,Y,i,j,sum=0;
    scanf("%d %d",&X,&Y);
    if(X>Y)
    {
        i=Y;
        j=X;
    }
    else
    {
        i=X;
        j=Y;
    }
    for(;i<=j;i++)
    {
        if(i%13!=0)
            sum+=i;
    }
    printf("%d\n",sum);
}

