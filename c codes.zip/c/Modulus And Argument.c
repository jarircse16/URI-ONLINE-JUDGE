#include<stdio.h>
#include<math.h>
int main()
{
    double s,i,m,a;
    printf("Enter numbers like a+ib or a-ib to calculate modulus and argument.");
    printf("\n");
    printf("Enter real and imaginary part serially:");
    scanf("%lf %lf",&s,&i);
    m=sqrt(s*s+i*i);
    a=atan(i/s)*180/3.1416;
    printf("Modulus is %lf",m);
    printf("\n");
    printf("Argument is %lf degrees",a);


}


