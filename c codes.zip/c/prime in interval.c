#include<stdio.h>
#include<math.h>

int isprime(int n)
{
    int i,k;
    int j=sqrt(n);
    for(i=0;i<j;i++)
    {
        if(n%i==0)
           k=0;
        else
            k=1;
    }
    return k;
}

int main()
{
//    int h,l,x;
//    printf("Enter highest value and lowest value serially:");
//    scanf("%d %d",&h,&l);
//    for(x=l;x<=h;x++)
//    {
//        if(isprime(x)==1)
//            printf("%d is prime",x);
//            else
//                printf("%d is not prime",x);
//    }

    printf("%d",isprime(5));
    return 0;

}
