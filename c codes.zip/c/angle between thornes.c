#include<stdio.h>


int main()
{
    int h,m;
    scanf("%d %d",&h,&m);
    double r=((60*h-11*m)/2.0);
    if(r>180)
        r=360-r;
    printf("%.9f",r);
    return 0;
}
