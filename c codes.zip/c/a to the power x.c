#include<stdio.h>
#include<math.h>
//use 20 iterations
long long facti(int n)
{
    int i,fact=1;
    for(i=1;i<=n;i++)
    {
        fact=fact*i;
    }
    if(n==0 || n==1)
        return 1;
    else
        return n*facti(n-1);
}

int main()
{
    int n,i;
    double sum=0.0,x,a;
    printf("Enter number of iterations:");
    scanf("%d",&n);
    printf("Enter the value of x and a for a to the power x:");
    scanf("%lf %lf",&x,&a);
    for(i=0;i<n;i++)
    {
        sum=sum+(pow((x*log(a)),i)/facti(i));
    }
    printf("Value of a^x for %d iterations is %lf",i,sum);
}

