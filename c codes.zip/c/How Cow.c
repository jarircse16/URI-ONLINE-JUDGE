#include<stdio.h>
#include<math.h>
int x1,x2,yone,y2,x,y;
int max(int a,int b)
{
    if(a>b)
        return a;
    else
        return b;
}
int min(int a,int b)
{
    if(a<b)
        return a;
    else
        return b;
}

int ici(int x1,int yone,int x2,int y2,int x,int y)
{
    int xmax=max(x1,x2);
    int ymax=max(yone,y2);
    int xmin=min(x1,x2);
    int ymin=min(yone,y2);
    if(x>xmin && x<xmax && y>ymin && y<ymax)
        return 1;
    else
        return 0;

}

int main()
{
    int n,cn=0,cs1,cs2;
    scanf("%d",&cs1);
    while(cs1--)
    {
        scanf("%d %d %d %d",&x1,&yone,&x2,&y2);
        scanf("%d",&cs2);
        while(cs2--)
        {
            scanf("%d %d",&x,&y);
            if(ici(x1,yone,x2,y2,x,y)==1)
                printf("Yes\n");
            else
                printf("No\n");
        }
    }
        return 0;
}
