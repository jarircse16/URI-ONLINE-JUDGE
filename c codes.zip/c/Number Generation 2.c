#include<stdio.h>

void main()
{
     int a[5]={0,1,3,5,6},c3=0;
     int i,j,k,l;
for(l=1;l<5;l++){

     for(i=0;i<5;i++)
     {

        for(j=0;j<5;j++)

        {
            for(k=0;k<5;k++)

                {
                if(a[l]==3 || a[l]==5 || a[l]==6){
                printf("A number is %d",a[l]);
                printf("%d",a[i]);
                printf("%d",a[j]);
                printf("%d\n",a[k]);
                c3++;
                }

                }

     }

     }


}
    printf("Total Numbers: %d",c3-1);
}
